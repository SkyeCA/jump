// Swapper.h

#if !defined(__SWAPPER_H__)
#define __SWAPPER_H__

#ifdef SWAPPER

__inline ulong SwapWords(ulong ul)
{
	return (ul >> 16) | (ul << 16);
}

__inline ushort SwapBytes(ushort us)
{
	return (us >> 8) | (us << 8);
}

__inline ulong SwapLong(ulong ul)
{
	return SwapWords(ul);
}

__inline ulong SwapShort(ushort us)
{
	return SwapBytes(us);
}

__inline ulong ReverseLong(ulong ul)
{
	return (ul >> 24) | ( ul << 24) | ((ul & 0x00FF0000) >> 8) | ((ul & 0x0000FF00) << 8);
}

#ifdef __cplusplus
extern "C" char *SwapChars(char *pszSwapped, const char *psz68);
#else
char *SwapChars(char *pszSwapped, const char *psz68);
#endif

#else // SWAPPER

#define SwapWords(ul) ul
#define SwapBytes(us) us
#define SwapLong(ul) ul
#define SwapShort(us) us
//#define Sz86(psz68) psz68

#endif // SWAPPER

#endif // !defined(__SWAPPER_H__)
