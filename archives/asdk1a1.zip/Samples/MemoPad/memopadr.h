/***********************************************************************
 *
 *	Copyright � Palm Computing 1995 -- All Rights Reserved
 *
 * PROJECT:  Memo Pad Sample Application
 * FILE:     MemoPadRsc.h (Phase 15)
 *
 * DESCRIPTION:
 *		Defined constants of the UI resources.
 *
 **********************************************************************/
 
#define	mainForm					1000		// main form of the application
#define	mainNewButton			1003		// new button of the main form
#define	mainEditButton			1004		// P5. new button of the main form
#define	mainTable				1005		// P12. record table of the main form
#define	mainCategoryTrigger	1007		// P11. activate the category list
#define	mainCategoryList		1008		// P11. the category list
#define	mainScrollUpButton	1009		// P13. scroll up button
#define	mainScrollDownButton	1010		// P13. scroll down button

#define	infoForm					1100		// P2. info form 

#define	editForm					1200		// P3. edit form
#define	editDoneButton			1202		// P3. done button of the edit form
#define	editField				1203		// P4. text field
#define	editDetailsButton		1205		// P10. details button of the edit form
#define	editCategoryTrigger	1207		// P11. activate the category list
#define	editCategoryList		1208		// P11. the category list
#define	editScrollUpButton	1209		// P13. scroll up button
#define	editScrollDownButton	1210		// P13. scroll down button
#define	editSmallFontButton	1211		// P16. small font button
#define	editLargeFontButton	1212		// P17. large font button
#define	editFontGroup			1


#define	editDeleteAlert		1210		// P9. delete memo alert
#define	editDeleteOK			0			// P9. delete memo alert OK button index

#define	detailsForm				1300		// P10. details form
#define	detailsOkButton		1302		// P10. OK button of the details form
#define	detailsCancelButton	1303		// P10. cancel button of the details form
#define	detailsDeleteButton	1304		// P10. delete button of the details form
#define	detailsPrivateChkbx	1306		// P10. private checkbox of the details form
#define	detailsCategoryTrigger	1311	// P11. category list trigger of the details form
#define	detailsCategoryList	1312		// P11. category list of the details form

#define	mainMenu					1050		// P2. menu bar for main form
#define	editMenu					1250		// P4. menu bar for edit form

#define	getInfoCmd				100		// P2. get info command on options menu
#define	goToTopCmd				101		// P4. top of text command on options menu
#define	goToBottomCmd			102		// P4. bottom of text command on options menu
#define	cutCmd					200		// P4. cut text command on edit menu
#define	copyCmd					201		// P4. copy text command on edit menu
#define	pasteCmd					202		// P4. paste text command on edit menu
#define	undoCmd					203		// P4. undo text change command on edit menu
#define	selectAllCmd			204		// P4. select all text command on edit menu
#define	editSeparator			205		// P4. separator line on edit menu
#define	keyboardCmd				206		// P4. display keyboard command on edit menu
#define	newPageCmd				300		// P9. new memo page on page menu
#define	deletePageCmd			301		// P9. delete memo page on page menu


// These are strings used by the application.  All text strings that the app uses should 
// be kept in resources so that the strings can be easily changed when localizing the 
// software for other languages.
#define findMemoPadHeaderStr	100
#define editTitleString			1000