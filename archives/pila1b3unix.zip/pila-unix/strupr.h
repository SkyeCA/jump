#ifndef __STRUPR_H__
#define __STRUPR_H__

void strupr(char *);

#endif /* __STRUPR_H__ */
