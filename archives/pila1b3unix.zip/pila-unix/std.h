#ifndef __STD_H__
#define __STD_H__

typedef int BOOL;
#define fTrue 1
#define fFalse 0
#define VOID void

//typedef unsigned char BYTE;

#include <assert.h>
#define Assert(f) assert(f)

#endif /* __STD_H__ */
