package palmos;

public class DaySelector {
  public short bounds_topLeft_x;
  public short bounds_topLeft_y;
  public short bounds_extent_x;
  public short bounds_extent_y;
  public boolean visible;
  public short visibleMonth;
  public short visibleYear;
  public short selected_second;
  public short selected_minute;
  public short selected_hour;
  public short selected_day;
  public short selected_month;
  public short selected_year;
  public short selected_weekDay;
}
