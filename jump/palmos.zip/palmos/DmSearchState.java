package palmos;

public class DmSearchState {
  private int info0;
  private int info1;
  private int info2;
  private int info3;
  private int info4;
  private int info5;
  private int info6;
  private int info7;
}
