package palmos;

public class DateTime {
  public short second;
  public short minute;
  public short hour;
  public short day;
  public short month;
  public short year;
  public short weekDay;
}
