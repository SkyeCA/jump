package palmos;

public class Debug {
  public native static void breakpoint();
}
