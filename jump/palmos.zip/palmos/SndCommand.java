package palmos;

public class SndCommand {
  public byte cmd;
  public int param1;
  public short param2;
  public short param3;
}
