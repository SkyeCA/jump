package palmos;

public class Rectangle {
  public short topLeft_x;
  public short topLeft_y;
  public short extent_x;
  public short extent_y;
}
