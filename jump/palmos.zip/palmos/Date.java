package palmos;

public class Date {
  public short ymd;
}
