package palmos;

public class PointType {
  public short x;
  public short y;
}
